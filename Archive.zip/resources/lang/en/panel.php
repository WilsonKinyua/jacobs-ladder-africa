<?php

return [
    'site_title' => 'Jacob\'s Ladder Africa',
];
